# Proxy

Proxy is handy when you need to run angular in local and wants to consume deployed WebAPI.

It uses NodeJS proxy service to make api calls without CORS. Adjust Your API Urls to do url rewrite.

PS: This happens outside angular so do not expect it to be running on production.
