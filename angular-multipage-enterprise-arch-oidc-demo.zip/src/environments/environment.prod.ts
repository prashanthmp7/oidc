export const environment = {
  production: true,

  issuer: 'https://demo.identityserver.io',
  clientId: 'interactive.public',
  apiEndpointsRequireAuth: ['https://demo.identityserver.io/api']
};
