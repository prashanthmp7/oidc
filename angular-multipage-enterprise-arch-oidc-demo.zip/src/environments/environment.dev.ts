export const environment = {
  production: false,

  issuer: 'https://demo.identityserver.io',
  clientId: 'interactive.public',
  apiEndpointsRequireAuth: ['https://demo.identityserver.io/api']
};
