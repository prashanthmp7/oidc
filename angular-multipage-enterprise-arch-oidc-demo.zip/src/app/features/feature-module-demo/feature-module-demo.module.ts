import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FeatureModuleDemoRoutingModule } from './feature-module-demo-routing.module';
import { FeatureModuleDemoComponent } from './feature-module-demo.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [FeatureModuleDemoComponent],
  imports: [CommonModule, FeatureModuleDemoRoutingModule, FormsModule]
})
export class FeatureModuleDemoModule {}
