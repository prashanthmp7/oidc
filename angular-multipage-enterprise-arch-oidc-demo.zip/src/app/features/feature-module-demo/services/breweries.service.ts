import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Brewery } from '../models/brewery';

@Injectable({
  providedIn: 'root'
})
export class BreweriesService {
  // This Service is only available in this feature

  constructor(private http: HttpClient) { }

  getBreweries(): Observable<Array<Brewery>> {
    return this.http.get<Array<Brewery>>(`https://api.openbrewerydb.org/breweries`);
  }

  findBrewery(param: { name: string }): Observable<Array<Brewery>> {
    return this.http.get<Array<Brewery>>(`https://api.openbrewerydb.org/breweries?by_name=${param.name}`);
  }
}
