import { Component, OnDestroy, OnInit } from '@angular/core';
import { IdentityClaims } from 'src/app/core/models/identity-claims';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { BreweriesService } from './services/breweries.service';
import { Brewery } from './models/brewery';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-feature-module-demo',
  templateUrl: './feature-module-demo.component.html',
  styleUrls: ['./feature-module-demo.component.scss']
})
export class FeatureModuleDemoComponent implements OnInit, OnDestroy {
  querySubscription: Subscription;
  breweries: Array<Brewery> = new Array<Brewery>();
  brewerySearchName = '';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private breweriesService: BreweriesService
  ) {
    this.querySubscription = this.route.queryParams
      .subscribe((params: Params) => this.handleQuery(params));
  }

  get identityClaims(): IdentityClaims {
    return this.authService.identityClaims;
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    this.querySubscription.unsubscribe();
  }

  getBreweries(): void {
    this.breweriesService.getBreweries().subscribe(
      breweries => this.breweries = breweries,
      error => this.breweries = []
    );
  }

  findBrewery(name: string): void {
    this.breweriesService.findBrewery({ name }).subscribe(
      breweries => this.breweries = breweries,
      error => this.breweries = []
    );
  }

  handleQuery(params: Params): void {
    if (Object.keys(params).length) {
      if (params.name) {
        this.findBrewery(params.name);
      }
    } else {
      this.getBreweries();
    }
  }

  searchByName(name: string): void {
    this.router.navigate(['.'], {
      relativeTo: this.route,
      queryParams: { name }
    }).then(_ => {
    });
  }

  clearSearch(): void {
    this.brewerySearchName = '';
    this.router.navigate(['.'], {
      relativeTo: this.route,
      queryParams: {}
    }).then(_ => {
    });
  }


  actionOnBrewery(brewery: Brewery): void {
    // Do some action to brewery object that will reflect all places
    brewery.postal_code = 'XXX XXX';
  }
}
