#Configurations

All type of global configs and enums that acts system level
