export enum ERROR_ROUTES {
  e500 = 'error',
  p401 = 'unauthorised',
  p403 = 'forbidden',
  p404 = 'page-not-found',
}
