export enum AUTH_ROUTES {
  login = 'login',
  logout = 'logout',
}
