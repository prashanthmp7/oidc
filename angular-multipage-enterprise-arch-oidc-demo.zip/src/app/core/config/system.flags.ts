export const homeRoute = 'home';

// Use HashLocationStrategy for routing?
export const useHash = false;

// Set this to true, to use silent refresh; otherwise the example
// uses the refresh_token via an AJAX call to get new tokens.
export const useSilentRefreshForCodeFlow = true;
