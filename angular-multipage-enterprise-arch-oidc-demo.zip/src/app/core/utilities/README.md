# Utility Classes

Classes that do not hold any data It will have at least one static method that accepts input then transforms and returns. Each Utility Class's method hold only have one purpose.
