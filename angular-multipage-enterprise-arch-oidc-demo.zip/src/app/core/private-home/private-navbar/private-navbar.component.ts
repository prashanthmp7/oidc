import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-navbar',
  templateUrl: './private-navbar.component.html',
  styleUrls: ['./private-navbar.component.scss'],
})
export class PrivateNavbarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
