import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-home',
  templateUrl: './private-home.component.html',
  styleUrls: ['./private-home.component.scss'],
})
export class PrivateHomeComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
