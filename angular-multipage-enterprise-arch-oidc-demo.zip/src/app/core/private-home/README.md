# Master Layout - Private

private-home component is a master layout for private pages which requires
authentication and authorisation. It also includes other components such as

- Navbar
- Sidebar
- Dashboard Home
  etc.,

Note: these components are not a shared item, in fact these components are
initialised only once and used at root level. Shared Module and Shared
Components are meant to be used in multiple modules.
