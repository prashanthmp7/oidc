import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p403',
  templateUrl: './p403.component.html',
  styleUrls: ['./p403.component.scss'],
})
export class P403Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
