import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-p401',
  templateUrl: './p401.component.html',
  styleUrls: ['./p401.component.scss'],
})
export class P401Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
