import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e500',
  templateUrl: './e500.component.html',
  styleUrls: ['./e500.component.scss'],
})
export class E500Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
