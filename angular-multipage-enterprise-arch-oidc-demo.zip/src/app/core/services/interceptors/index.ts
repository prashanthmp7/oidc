import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorInterceptor } from './error.interceptor';
import { NotifyInterceptor } from './notify.interceptor';
import { LoaderInterceptor } from './loader.interceptor';
import { HttpsInterceptor } from './https.interceptor';
import { HeaderInterceptor } from './header.interceptor';
import { CacheInterceptor } from './cache.interceptor';
import { FakeInterceptor } from './fake.interceptor';
import { ProfilerInterceptor } from './profiler.interceptor';

export const HTTP_INTERCEPTOR_PROVIDERS = [
  // { provide: HTTP_INTERCEPTORS, useClass: CacheInterceptor, multi: true },
  // {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true},
  // { provide: HTTP_INTERCEPTORS, useClass: FakeInterceptor, multi: true },
  // {provide: HTTP_INTERCEPTORS, useClass: HeaderInterceptor, multi: true},
  // { provide: HTTP_INTERCEPTORS, useClass: HttpsInterceptor, multi: true },
  // {provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true},
  // { provide: HTTP_INTERCEPTORS, useClass: ProfilerInterceptor, multi: true },
  // {provide: HTTP_INTERCEPTORS, useClass: NotifyInterceptor, multi: true},
];
