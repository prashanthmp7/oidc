# Services

Services That are active throughout the lifecycle of angular app should be added here. If there service that is relevant only for a module use `providedIn: ModuleName`.

`Important: There is nothing as such shared service. There are only services that provided in root or provided only in a feature`
