Everything that is stay alive through the lifetime is added here

---

P-\* components are pages

E-\* components are error

---

PUBLIC Routes are meant to be used without Auth.

PRIVATE Routes are for authenticated users, it can be authorised or unauthorised pages.

---
